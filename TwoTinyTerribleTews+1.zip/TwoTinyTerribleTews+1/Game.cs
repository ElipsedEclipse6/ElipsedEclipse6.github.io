﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoTinyTerribleTews_1
{
    internal class Game
    {
        EasyOverDayCare easyoverdaycare = new EasyOverDayCare();
        Player Player1 = new Player();
        Lola lola= new Lola();
        Dungby dungby = new Dungby();

        public Game() 
        {
            Start();
        }
        public void Start()
        {         
            lola.Welcome1A();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Player1.name = Console.ReadLine();
            Player1.age = 7;
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Print("\n\nOh! What a beautiful name! \nNice to meet you, " + Player1.name + "!",10);
            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Mrs.Lola");
            Print("Now lets see! Our little " + Player1.name + " is...uuuummmm....." + Player1.age + " Years old!! \nWow! That means you're the 3rd oldest egg in here! \n\nIm counting on you to help guide the younger ones!\nI know you wont let me down!\n\n",10);
            Console.ReadLine();

            //Start Travel Narration
            lola.Tour();
            dungby.PhoneHack();
          

            
            
            
            
            
            



     
        }
        public static void Print(string text,int speed) 
        {
            foreach (char c in text) 
            {
                Console.Write(c);
                System.Threading.Thread.Sleep(speed);
            
            
            
            }
        
        
        
        }
    }
}

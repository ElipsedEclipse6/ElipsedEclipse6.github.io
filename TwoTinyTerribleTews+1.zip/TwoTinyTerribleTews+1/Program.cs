﻿using Microsoft.VisualBasic;

namespace TwoTinyTerribleTews_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new Game();
            
           
  
            
            
        }


    }
}
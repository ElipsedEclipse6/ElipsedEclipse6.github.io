﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoTinyTerribleTews_1
{
    internal class LoganTew
    {
        string name;
        int age;
        string Favoritefood;
        string Favoritecolor;

    }
}

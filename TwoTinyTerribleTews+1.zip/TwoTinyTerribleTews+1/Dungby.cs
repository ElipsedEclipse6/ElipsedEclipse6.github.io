﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoTinyTerribleTews_1
{
    internal class Dungby
    {
        public string name = "Mr. Dungby";
        public int age = 35;
        public string Favoritecolor = "green";
        public string favoritefood = "Pizza";
        string Attempt = "";
        bool phoneBuzzes = false;




        static void Snore() 
        {
            Console.WriteLine("ZZZZZZzzzzzzzzzzzz......ZZZZZZZZZzzzzzzzz......ZZZZZZZZZ........AAAAHHHHHHHZZZZZZZZZZzzzzzzz...");
        
        
        
        }
        public void PhoneHack() 
        {
            int age = 35;
            string favoritefood = "pizza";
            string attempt = "";
            int attemptCount = 0;
            int attemptLimit = 5;
            bool noMoreattempts = false;


            while(attempt != favoritefood && !noMoreattempts) 
            {
                Console.Write("Psssword hint: What is my favorite food?:\n Enter Password to continue: ");
                Console.ReadLine();
                

                if (attemptCount < attemptLimit) 
                {
                    Console.WriteLine("Please enter password: ");
                    attempt = Console.ReadLine();
                    attemptCount++;



                }
                else 
                {
                    noMoreattempts = true;
                
                
                
                
                }
                
                
              
            
            
            
            
            
            
            }

            if (noMoreattempts) 
            {
                WakeUp();
            
            
            
            
            }
            else 
            {
                Print("Success!!! You've Unlocked the phone!!",10);
                Console.ReadLine();
                Console.Clear();
                Print("The trio unlocks the room door and heads to Mrs.Lolas office for the final stretch... ",10);

            
            
            
            
            
            }
           

            Console.ReadLine();

        
        
        
        
        } 
        public void WakeUp() 
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("ZZZZZZZZzz-Huh!!!! Hey! What are you kids doing!?");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Print("Uh...Oh! Were sorry Mr. Dungby!",10);
            Console.WriteLine("Time out for all 3 of you!\n No snacks either!!\n I will tell Mrs.Lola when she wakes!!");
            Console.ReadLine();
          


        
        
        
        
        }

        public void GameOver() 
        {
            Game game = new Game();
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Red;
            Console.ForegroundColor = ConsoleColor.Black;
            Print("GAME OVER....",50);
            Console.ReadLine();
            game.Start();
            




        }
        public static void Print(string text, int speed)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                System.Threading.Thread.Sleep(speed);



            }



        }

    }

    
}

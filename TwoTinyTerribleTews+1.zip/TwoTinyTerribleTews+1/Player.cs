﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoTinyTerribleTews_1
{
    internal class Player
    {
        public string name;
        public int age = 7;
        public string Favoritefood;
        public string Favoritecolor;

        public void Answer1() 
        {
            string answer;
            int answer1;


            Console.ReadLine();

            
            

        
        
        
        }


        





    }
}

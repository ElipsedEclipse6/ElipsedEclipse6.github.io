﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoTinyTerribleTews_1
{
    internal class Library
    {
        public string books;


        public void BabyWakeUp()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("Loud Baby Cries!!!!");
            Console.WriteLine("Mr. Dungby come running into the library!\n Hey! what are you kids doing??");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Print("Uh...Oh! Were sorry Mr. Dungby!", 10);
            Console.WriteLine("Time out for all 3 of you!\n No snacks either!!\n I will tell Mrs.Lola when she wakes!!");
            Console.ReadLine();







        }

        public void GameOver()
        {
            Game game = new Game();
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Red;
            Console.ForegroundColor = ConsoleColor.Black;
            Print("GAME OVER....", 50);
            Console.ReadLine();
            game.Start();





        }
        public static void Print(string text, int speed)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                System.Threading.Thread.Sleep(speed);



            }



        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace TwoTinyTerribleTews_1
{
    internal class Lola
    {
        public string name = "Mrs.Lola";
        public int age = 23;
        public string Favoritefood = "Tacos";
        public string favoritecolor = "chartreuse";
        




        public void Welcome1A() 
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            //Console.WriteLine("Hello! Welcome to Easy Over Daycare! My name is Mrs.Lola! Who's this little angel?");
            Console.WriteLine("Mrs.Lola");
            Print( "\nWell hello! My name is " + name + ", \nAnd who might this little angel be?\n\n", 10);
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Enter Your Name: ");
            






        }
        public void Tour()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Print("Well come on in!! I'll show you around!\nAll of he other students arrived before you.I can't wait for you to meet everyone!\n\n", 5);
            Console.ReadLine();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;
            string traveltext = @"E:\TwoTinyTerribleTews+1\Traveling.txt";
            List<string> lines = new List<string>();
            lines = File.ReadAllLines(traveltext).ToList();

            foreach (String line in lines)
            {
                Print(line, 10);


            }
            Console.ReadLine();



        }

        public void PickAColor() 
        {
            Random roomNum = new Random();
            int Room = roomNum.Next();
            Console.WriteLine("Room #: " + roomNum.Next(100, 999));

            Random c = new Random();
            String[] Colors = { "Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet" };
            
            Console.WriteLine(Colors[0], 6);
            
        
        
        
        }
        public static void Print(string text, int speed)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                System.Threading.Thread.Sleep(speed);



            }



        }


    }
}

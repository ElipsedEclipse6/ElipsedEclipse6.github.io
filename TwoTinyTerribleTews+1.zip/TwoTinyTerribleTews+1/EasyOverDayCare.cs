﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoTinyTerribleTews_1
{
    internal class EasyOverDayCare
    {
        
        static void FloorCreak() 
        {
        
        }
        public static void Print(string text, int speed)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                System.Threading.Thread.Sleep(speed);



            }



        }

    }
}
